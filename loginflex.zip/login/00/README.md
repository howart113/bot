# 🕵 แมวเป้🔰ไร้สังกัด 🕵

1. apt update
2. apt upgrade
3. pkg install python3
4. pkg install pip3
5. pkg install git
6. git clone https://github.com/Fcpea150/00
7. pkg install nano
8. pip3 install rsa
9. pip3 install thrift==0.11.0
10. pip3 install requests
11. pip3 install bs4
12. pip3 install gtts
13. pip3 install pytz
14. pip3 install humanfriendly
15. pip3 install googletrans
16. pip3 install antolib
17. pip3 install linepy
18. pip3 install akad
19. cd 00
20. nano 01.py
21. python3 01.py

LINE ID: fcpea122
BY: SELFBOT-BY:MAX
